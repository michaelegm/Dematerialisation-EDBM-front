import React from "react";
import { Route, Switch, BrowserRouter } from "react-router-dom";
import Home from "./front/containers/Home";
import Information from "./front/containers/Information"
import Outils from "./front/containers/Outils";
import Dossier from"./front/containers/Dossier";
import CGU from"./front/containers/CGU";
import Faq from"./front/containers/faq";
import Connexion from"./front/containers/Connexion";
import InscriptionPage from"./front/containers/Inscription";
import DossierActivite from "./front/containers/DossierActivite";
import OutilsDroit from "./front/containers/OutilsDroit";

export default function Routes() {
  return (
      <BrowserRouter>
      <Switch>
        <Route exact path="/">
          <Home />
        </Route>
        <Route exact path="/connexion">
          <Connexion />
        </Route>
        <Route exact path="/inscription">
          <InscriptionPage />
        </Route>
        <Route exact path="/information">
          <Information />
        </Route>
        <Route exact path="/outils">
          <Outils />
        </Route>
        <Route exact path="/dossier">
          <Dossier />
        </Route>
        <Route exact path="/cgu">
          <CGU />
        </Route>
        <Route exact path="/faq">
          <Faq />
        </Route>

        <Route exact path="/dossier_activite">
          <DossierActivite/>
        </Route>
        <Route exact path="/outils_simulation">
          <OutilsDroit/>
        </Route>
      </Switch>
      </BrowserRouter>
  );
}
